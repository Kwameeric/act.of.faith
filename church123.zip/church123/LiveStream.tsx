import { useState } from 'react';
import { Radio, MessageSquare, Clock, Users, UserPlus, Bell, BellRing, CheckCircle2, ShieldCheck, Send, ExternalLink } from 'lucide-react';
import { useChurch } from '../context/ChurchContext';
import MoMoSection from '../components/MoMoSection';
import BankTransferSection from '../components/BankTransferSection';

// Helper function to convert regular video links to embed links automatically
function getEmbedUrl(url: string): string | null {
  if (!url) return null;
  
  // If it's already an embed link, leave it alone
  if (url.includes('/embed/')) return url;

  // Standard YouTube watch link (e.g., https://www.youtube.com/watch?v=VIDEO_ID)
  if (url.includes('youtube.com/watch?v=')) {
    const videoId = url.split('v=')[1]?.split('&')[0];
    return `https://www.youtube.com/embed/${videoId}`;
  }

  // YouTube short link (e.g., https://youtu.be/VIDEO_ID)
  if (url.includes('youtu.be/')) {
    const videoId = url.split('youtu.be/')[1]?.split('?')[0];
    return `https://www.youtube.com/embed/${videoId}`;
  }

  // YouTube Live link (e.g., https://www.youtube.com/live/VIDEO_ID)
  if (url.includes('youtube.com/live/')) {
    const videoId = url.split('live/')[1]?.split('?')[0];
    return `https://www.youtube.com/embed/${videoId}`;
  }

  // Vimeo link (e.g., https://vimeo.com/VIDEO_ID)
  if (url.includes('vimeo.com/')) {
    const videoId = url.split('vimeo.com/')[1]?.split('?')[0];
    return `https://player.vimeo.com/video/${videoId}`;
  }

  // TikTok Live link (e.g., https://www.tiktok.com/@username/live)
  if (url.includes('tiktok.com/@') && url.includes('/live')) {
    const usernamePart = url.split('tiktok.com/@')[1];
    const username = usernamePart.split('/')[0];
    return `https://www.tiktok.com/embed/@${username}/live`;
  }

  // Facebook Live link (e.g., https://www.facebook.com/yourpage/videos/123456 or fb.watch/abc)
  if (url.includes('facebook.com/') || url.includes('fb.watch/')) {
    const encodedUrl = encodeURIComponent(url);
    return `https://www.facebook.com/plugins/video.php?href=${encodedUrl}&show_text=false&autoplay=true&mute=0`;
  }

  // If it's a direct video file (mp4) or another link, just return it as is
  return url;
}

export default function LiveStream() {
  const { data, joinOnlineMember, subscribeToNotifications, submitLiveOffering } = useChurch();
  const [chat, setChat] = useState<{ name: string; text: string; time: number }[]>([]);
  const [name, setName] = useState('');
  const [text, setText] = useState('');

  // Online Member form
  const [showJoinForm, setShowJoinForm] = useState(false);
  const [joinForm, setJoinForm] = useState({ fullName: '', email: '', phone: '', country: '' });
  const [joined, setJoined] = useState(false);

  // Notification subscription
  const [showNotifyForm, setShowNotifyForm] = useState(false);
  const [notifyForm, setNotifyForm] = useState({ fullName: '', email: '', phone: '', country: '' });
  const [subscribed, setSubscribed] = useState(false);
  const [permStatus, setPermStatus] = useState<'idle' | 'granted' | 'denied'>('idle');

  // MoMo Offering
  const [offeringForm, setOfferingForm] = useState({ fullName: '', amount: 0, reference: '', message: '' });
  const [offeringSubmitted, setOfferingSubmitted] = useState(false);

  const alreadyMember = data.onlineMembers.some(m => m.email === joinForm.email);
  const alreadySubscribed = data.notifySubscribers.some(s => s.email === notifyForm.email);

  // Convert the link from Admin Dashboard into a playable embed link
  const embedUrl = getEmbedUrl(data.livestreamUrl);

  // Check if the link is from a platform that blocks embedding (Instagram, X/Twitter)
  const isInstagram = data.livestreamUrl?.includes('instagram.com');
  const isTwitter = data.livestreamUrl?.includes('twitter.com') || data.livestreamUrl?.includes('x.com');
  const isUnembeddableSocial = isInstagram || isTwitter;

  const send = () => {
    if (!text.trim() || !name.trim()) return;
    setChat(c => [...c, { name: name.trim(), text: text.trim(), time: Date.now() }]);
    setText('');
  };

  const handleJoin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!joinForm.fullName || !joinForm.email) return;
    joinOnlineMember(joinForm);
    setJoined(true);
  };

  const handleSubscribe = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!notifyForm.fullName || !notifyForm.email) return;
    const granted = await subscribeToNotifications(notifyForm);
    setPermStatus(granted ? 'granted' : 'denied');
    setSubscribed(true);
  };

  const handleOffering = (e: React.FormEvent) => {
    e.preventDefault();
    if (!offeringForm.fullName || !offeringForm.amount) return;
    submitLiveOffering(offeringForm);
    setOfferingSubmitted(true);
    setOfferingForm({ fullName: '', amount: 0, reference: '', message: '' });
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10">
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <div>
          <div className="inline-flex items-center gap-2 bg-red-100 text-red-700 px-3 py-1 rounded-full text-sm font-medium">
            <span className={`h-2 w-2 rounded-full ${data.isLive ? 'bg-red-500 animate-pulse' : 'bg-slate-400'}`} />
            {data.isLive ? 'LIVE NOW' : 'OFFLINE'}
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold text-slate-900 mt-3">Live Stream Service</h1>
          <p className="text-slate-600 mt-2">Join us from anywhere in the world. Worship with us in real time.</p>
        </div>
        <div className="flex items-center gap-2 bg-slate-100 px-3 py-2 rounded-xl text-sm">
          <Users className="h-4 w-4 text-slate-600" />
          <span className="font-semibold text-slate-700">{data.onlineMembers.length}</span>
          <span className="text-slate-500">online members</span>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Stream + Action Cards */}
        <div className="lg:col-span-2 space-y-5">
          <div className="relative w-full aspect-video rounded-2xl overflow-hidden bg-slate-900 shadow-2xl">
            
            {/* If we have an embeddable URL (YouTube, TikTok, FB, Vimeo) */}
            {embedUrl && !isUnembeddableSocial ? (
              <iframe
                key={embedUrl}
                src={embedUrl}
                title="Live Stream"
                className="absolute inset-0 w-full h-full"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              />
            ) : 
            /* If it's Instagram or Twitter, show a redirect screen */
            isUnembeddableSocial ? (
              <div className="absolute inset-0 flex flex-col items-center justify-center text-white p-6 text-center bg-gradient-to-br from-slate-800 to-slate-950">
                <Radio className="h-12 w-12 text-red-500 mb-4 animate-pulse" />
                <h3 className="text-2xl font-bold mb-2">We Are Live Now!</h3>
                <p className="text-sm text-white/60 mb-6 max-w-md">
                  {isInstagram ? 'Instagram' : 'X (Twitter)'} does not allow live streams to be played directly on other websites. Please tap the button below to watch directly on the app.
                </p>
                <a 
                  href={data.livestreamUrl} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="px-6 py-3 bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white font-bold rounded-xl flex items-center gap-2 shadow-lg transition"
                >
                  Watch on {isInstagram ? 'Instagram' : 'X'} <ExternalLink className="h-5 w-5" />
                </a>
              </div>
            ) : (
              /* If there is no link at all */
              <div className="absolute inset-0 flex flex-col items-center justify-center text-white/80 p-4 text-center">
                <Radio className="h-12 w-12 text-red-500 mb-4" />
                <h3 className="text-xl font-bold mb-2">No Live Stream Available</h3>
                <p className="text-sm text-white/60">
                  The stream is currently offline. Please check back during our service times (Sundays at 9AM).
                </p>
              </div>
            )}
          </div>

          <div className="bg-white rounded-2xl p-5 shadow border border-slate-100 grid sm:grid-cols-3 gap-4">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-lg bg-red-100 flex items-center justify-center"><Radio className="h-5 w-5 text-red-600" /></div>
              <div>
                <p className="text-xs text-slate-500">Status</p>
                <p className="font-semibold text-sm">{data.isLive ? 'Broadcasting' : 'Offline'}</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-lg bg-blue-100 flex items-center justify-center"><Clock className="h-5 w-5 text-blue-600" /></div>
              <div>
                <p className="text-xs text-slate-500">Service</p>
                <p className="font-semibold text-sm">Sundays 9AM</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-lg bg-amber-100 flex items-center justify-center"><BellRing className="h-5 w-5 text-amber-600" /></div>
              <div>
                <p className="text-xs text-slate-500">Subscribers</p>
                <p className="font-semibold text-sm">{data.notifySubscribers.length} notified</p>
              </div>
            </div>
          </div>

          {/* Two action cards side by side */}
          <div className="grid sm:grid-cols-2 gap-4">
            {/* Join as Online Member */}
            {!joined && !alreadyMember ? (
              <div className="bg-gradient-to-br from-indigo-600 to-indigo-800 text-white rounded-2xl p-6 shadow-xl">
                <div className="flex items-center gap-3 mb-3">
                  <div className="h-10 w-10 rounded-xl bg-white/20 flex items-center justify-center backdrop-blur">
                    <UserPlus className="h-5 w-5 text-white" />
                  </div>
                  <h3 className="font-bold text-lg">Become an Online Member</h3>
                </div>
                <p className="text-sm text-indigo-100 mb-4">
                  Join our online community. Get connected, receive updates, and be part of the family from anywhere in the world.
                </p>
                <button
                  onClick={() => setShowJoinForm(true)}
                  className="w-full py-3 bg-white text-indigo-700 font-bold rounded-xl hover:bg-indigo-50 transition"
                >
                  Join Now →
                </button>
              </div>
            ) : (
              <div className="bg-gradient-to-br from-emerald-500 to-emerald-700 text-white rounded-2xl p-6 shadow-xl">
                <div className="flex items-center gap-3 mb-3">
                  <div className="h-10 w-10 rounded-xl bg-white/20 flex items-center justify-center">
                    <CheckCircle2 className="h-5 w-5" />
                  </div>
                  <h3 className="font-bold text-lg">Welcome, Member!</h3>
                </div>
                <p className="text-sm text-emerald-50">
                  You're now registered as an online member of {data.name}. God bless you!
                </p>
                <p className="text-xs text-emerald-100 mt-3">
                  {alreadyMember
                    ? `Connected as: ${data.onlineMembers.find(m => m.email === (alreadyMember ? joinForm.email : ''))?.email || joinForm.email}`
                    : `Joined as: ${joinForm.email}`}
                </p>
              </div>
            )}

            {/* Notify Me When Live */}
            {!subscribed && !alreadySubscribed ? (
              <div className="bg-gradient-to-br from-amber-500 to-orange-600 text-white rounded-2xl p-6 shadow-xl">
                <div className="flex items-center gap-3 mb-3">
                  <div className="h-10 w-10 rounded-xl bg-white/20 flex items-center justify-center backdrop-blur">
                    <Bell className="h-5 w-5 text-white" />
                  </div>
                  <h3 className="font-bold text-lg">Notify Me When Live</h3>
                </div>
                <p className="text-sm text-amber-50 mb-4">
                  Never miss a service! Get instant notifications when we go live.
                </p>
                <button
                  onClick={() => setShowNotifyForm(true)}
                  className="w-full py-3 bg-white text-amber-700 font-bold rounded-xl hover:bg-amber-50 transition"
                >
                  🔔 Subscribe to Alerts
                </button>
              </div>
            ) : (
              <div className="bg-gradient-to-br from-purple-600 to-pink-600 text-white rounded-2xl p-6 shadow-xl">
                <div className="flex items-center gap-3 mb-3">
                  <div className="h-10 w-10 rounded-xl bg-white/20 flex items-center justify-center">
                    <ShieldCheck className="h-5 w-5" />
                  </div>
                  <h3 className="font-bold text-lg">You're Subscribed!</h3>
                </div>
                <p className="text-sm text-purple-50">
                  {permStatus === 'granted'
                    ? 'Browser notifications are ON. You\'ll be alerted when we go live.'
                    : 'You\'re on our list! We\'ll reach you via email when we go live.'}
                </p>
                <p className="text-xs text-purple-100 mt-3">
                  {alreadySubscribed ? '✓ Registered' : `Subscribed: ${notifyForm.email}`}
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Live Chat */}
        <div className="bg-white rounded-2xl shadow border border-slate-100 flex flex-col h-[640px]">
          <div className="p-4 border-b border-slate-100">
            <h3 className="font-bold flex items-center gap-2"><MessageSquare className="h-5 w-5 text-amber-600" /> Live Chat</h3>
          </div>

          <div className="flex-1 overflow-y-auto p-3 space-y-2">
            {chat.length === 0 && (
              <p className="text-center text-sm text-slate-400 py-8">Be the first to say hello! 🙏</p>
            )}
            {chat.map((m, i) => (
              <div key={i} className="text-sm">
                <span className="font-semibold text-indigo-700">{m.name}: </span>
                <span className="text-slate-700">{m.text}</span>
              </div>
            ))}
          </div>

          <div className="p-3 border-t border-slate-100 space-y-2">
            <input
              value={name}
              onChange={e => setName(e.target.value)}
              placeholder="Your name"
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 outline-none"
            />
            <div className="flex gap-2">
              <input
                value={text}
                onChange={e => setText(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && send()}
                placeholder="Say something..."
                className="flex-1 px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 outline-none"
              />
              <button onClick={send} className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-white rounded-lg text-sm font-medium">Send</button>
            </div>
          </div>
        </div>
      </div>

      {/* Join Online Member Modal */}
      {showJoinForm && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4" onClick={() => setShowJoinForm(false)}>
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl" onClick={e => e.stopPropagation()}>
            <h3 className="text-xl font-bold text-slate-900 mb-1 flex items-center gap-2">
              <UserPlus className="h-5 w-5 text-indigo-600" /> Join as Online Member
            </h3>
            <p className="text-sm text-slate-600 mb-5">Fill in your details to become part of our online family.</p>
            <form onSubmit={handleJoin} className="space-y-3">
              <input required value={joinForm.fullName} onChange={e => setJoinForm(f => ({ ...f, fullName: e.target.value }))} placeholder="Full Name *" className="w-full px-3 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none" />
              <input required type="email" value={joinForm.email} onChange={e => setJoinForm(f => ({ ...f, email: e.target.value }))} placeholder="Email *" className="w-full px-3 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none" />
              <input value={joinForm.phone} onChange={e => setJoinForm(f => ({ ...f, phone: e.target.value }))} placeholder="Phone (optional)" className="w-full px-3 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none" />
              <input value={joinForm.country} onChange={e => setJoinForm(f => ({ ...f, country: e.target.value }))} placeholder="Country (optional)" className="w-full px-3 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none" />
              <div className="flex gap-2 pt-2">
                <button type="button" onClick={() => setShowJoinForm(false)} className="flex-1 py-2.5 border border-slate-300 text-slate-700 rounded-lg font-medium hover:bg-slate-50">Cancel</button>
                <button type="submit" className="flex-1 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-semibold">Join</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MoMo Live Stream Offering Section */}
      <section className="mt-8">
        <MoMoSection
          number={data.momoNumber}
          name={data.momoName}
          network={data.momoNetwork}
          title="Support the Live Stream via MoMo"
          description="Your offering helps us keep the gospel streaming to the nations. Tap below to send your seed directly."
          instructions="💡 Steps: Tap 'Send via MoMo' → Dialer opens → Call ends → Open MoMo app → Send Money → Enter amount → Use your name as reference → Confirm PIN."
        />
        <div className="grid md:grid-cols-2 gap-6 mt-6">
          {/* Left: Bank Transfer */}
          <BankTransferSection
            variant="compact"
            bankName={data.bankName}
            accountName={data.accountName}
            accountNumber={data.accountNumber}
            paymentLink={data.paymentLink}
            reference="LIVE STREAM"
          />

          <div>
          {/* Right: Offering Confirmation Form */}
          <div className="bg-white rounded-2xl p-5 sm:p-6 shadow-xl">
            {!offeringSubmitted ? (
              <>
                <h3 className="font-bold text-slate-900 text-lg mb-1 flex items-center gap-2">
                  <Send className="h-5 w-5 text-emerald-600" /> Log Your Offering
                </h3>
                <p className="text-xs text-slate-600 mb-4">After sending via MoMo, optionally confirm your gift here so we can pray for you.</p>
                <form onSubmit={handleOffering} className="space-y-3">
                  <input
                    required
                    value={offeringForm.fullName}
                    onChange={e => setOfferingForm(f => ({ ...f, fullName: e.target.value }))}
                    placeholder="Your Full Name *"
                    className="w-full px-3 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none text-sm"
                  />
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      required
                      type="number"
                      min="0"
                      step="0.01"
                      value={offeringForm.amount || ''}
                      onChange={e => setOfferingForm(f => ({ ...f, amount: Number(e.target.value) }))}
                      placeholder="Amount *"
                      className="px-3 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none text-sm"
                    />
                    <input
                      value={offeringForm.reference}
                      onChange={e => setOfferingForm(f => ({ ...f, reference: e.target.value }))}
                      placeholder="Transaction ID"
                      className="px-3 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none text-sm"
                    />
                  </div>
                  <textarea
                    value={offeringForm.message}
                    onChange={e => setOfferingForm(f => ({ ...f, message: e.target.value }))}
                    placeholder="Prayer request or testimony (optional)"
                    rows={2}
                    className="w-full px-3 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none text-sm resize-none"
                  />
                  <button
                    type="submit"
                    className="w-full py-3 bg-gradient-to-r from-emerald-600 to-green-700 hover:from-emerald-700 hover:to-green-800 text-white font-bold rounded-xl shadow-lg flex items-center justify-center gap-2"
                  >
                    <CheckCircle2 className="h-5 w-5" /> Submit Offering
                  </button>
                  <p className="text-[11px] text-center text-slate-500">This form is optional — your offering is counted in heaven regardless.</p>
                </form>
              </>
            ) : (
              <div className="text-center py-8">
                <div className="h-16 w-16 mx-auto rounded-full bg-gradient-to-br from-emerald-500 to-green-600 flex items-center justify-center mb-4 shadow-lg">
                  <CheckCircle2 className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-xl font-bold text-slate-900 mb-2">Thank You!</h3>
                <p className="text-sm text-slate-600 mb-4">
                  Your offering has been received. God bless the work of your hands and multiply your seed!
                </p>
                <blockquote className="italic text-sm text-slate-700 bg-emerald-50 border-l-4 border-emerald-500 p-3 rounded text-left">
                  "Give, and it will be given to you. A good measure, pressed down, shaken together and running over..."
                  <footer className="text-xs text-emerald-700 font-semibold mt-1">— Luke 6:38</footer>
                </blockquote>
                <button
                  onClick={() => setOfferingSubmitted(false)}
                  className="mt-5 text-sm text-emerald-700 hover:text-emerald-900 font-medium underline"
                >
                  Submit another offering
                </button>
              </div>
            )}
          </div>
          </div>
        </div>
      </section>

      {/* Notify Me Modal */}
      {showNotifyForm && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4" onClick={() => setShowNotifyForm(false)}>
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl" onClick={e => e.stopPropagation()}>
            <h3 className="text-xl font-bold text-slate-900 mb-1 flex items-center gap-2">
              <BellRing className="h-5 w-5 text-amber-600" /> Get Live Notifications
            </h3>
            <p className="text-sm text-slate-600 mb-4">We'll send you a browser notification whenever we go live. You'll also be added to our members list.</p>
            {typeof Notification !== 'undefined' && Notification.permission === 'denied' && (
              <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg text-xs text-red-700">
                ⚠️ Browser notifications are blocked. Please enable them in your browser settings to receive alerts.
              </div>
            )}
            <form onSubmit={handleSubscribe} className="space-y-3">
              <input required value={notifyForm.fullName} onChange={e => setNotifyForm(f => ({ ...f, fullName: e.target.value }))} placeholder="Full Name *" className="w-full px-3 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 outline-none" />
              <input required type="email" value={notifyForm.email} onChange={e => setNotifyForm(f => ({ ...f, email: e.target.value }))} placeholder="Email *" className="w-full px-3 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 outline-none" />
              <input value={notifyForm.phone} onChange={e => setNotifyForm(f => ({ ...f, phone: e.target.value }))} placeholder="Phone (optional)" className="w-full px-3 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 outline-none" />
              <input value={notifyForm.country} onChange={e => setNotifyForm(f => ({ ...f, country: e.target.value }))} placeholder="Country (optional)" className="w-full px-3 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 outline-none" />
              <div className="flex gap-2 pt-2">
                <button type="button" onClick={() => setShowNotifyForm(false)} className="flex-1 py-2.5 border border-slate-300 text-slate-700 rounded-lg font-medium hover:bg-slate-50">Cancel</button>
                <button type="submit" className="flex-1 py-2.5 bg-amber-500 hover:bg-amber-600 text-white rounded-lg font-semibold">Subscribe 🔔</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}