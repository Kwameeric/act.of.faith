import { useState } from 'react';
import { Save, Plus, Trash2, Upload, Settings, Image as ImageIcon, Film, Users2, Calendar, MapPin, Home, Building2, BookOpen, Lock, Inbox, Radio, BellRing, UserPlus, Truck, HandHeart, CreditCard, Heart, ShoppingCart } from 'lucide-react';
import { useChurch } from '../context/ChurchContext';

import { Book } from '../context/ChurchContext';

type Tab = 'general' | 'hero' | 'founder' | 'books' | 'members' | 'events' | 'branches' | 'media' | 'orphanage' | 'building' | 'bible' | 'partners' | 'livestream' | 'home-gallery' | 'crusade-truck' | 'building-auditorium' | 'orphanage-donations' | 'payment' | 'book-orders';

function isImageUrl(value: string): boolean {
  if (!value) return false;
  return value.startsWith('data:image/') ||
    value.startsWith('http://') ||
    value.startsWith('https://') ||
    value.startsWith('/') ||
    value.endsWith('.png') ||
    value.endsWith('.jpg') ||
    value.endsWith('.jpeg') ||
    value.endsWith('.webp') ||
    value.endsWith('.gif') ||
    value.endsWith('.svg');
}

export default function Admin() {
  const { data, updateField, setLive, broadcastLiveNotification } = useChurch();
  const [tab, setTab] = useState<Tab>('general');
  const [saved, setSaved] = useState(false);
  const [pinInput, setPinInput] = useState('');
  const [pinVerified, setPinVerified] = useState(() => {
    try { return sessionStorage.getItem('adminPinVerified') === 'true'; } catch { return false; }
  });
  const [pinError, setPinError] = useState('');

  const handlePinSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (pinInput === data.adminPin) {
      setPinVerified(true);
      setPinError('');
      try { sessionStorage.setItem('adminPinVerified', 'true'); } catch {}
    } else {
      setPinError('Incorrect PIN. Please try again.');
      setPinInput('');
    }
  };

  const handleLogout = () => {
    setPinVerified(false);
    setPinInput('');
    try { sessionStorage.removeItem('adminPinVerified'); } catch {}
  };

  // PIN Entry Screen
  if (!pinVerified) {
    return (
      <div className="min-h-[80vh] flex items-center justify-center px-4 py-12">
        <div className="max-w-md w-full">
          <div className="bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden">
            <div className="bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 p-8 text-center text-white">
              <div className="h-16 w-16 mx-auto rounded-2xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center mb-4 shadow-xl">
                <Lock className="h-8 w-8 text-slate-900" />
              </div>
              <h1 className="text-2xl font-bold mb-2">Admin Dashboard</h1>
              <p className="text-slate-300 text-sm">Enter your PIN to access admin controls</p>
            </div>

            <form onSubmit={handlePinSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Admin PIN</label>
                <input
                  type="password"
                  value={pinInput}
                  onChange={e => { setPinInput(e.target.value); setPinError(''); }}
                  placeholder="Enter PIN"
                  autoFocus
                  maxLength={10}
                  className="w-full px-4 py-3 border-2 border-slate-300 rounded-xl text-center text-2xl tracking-widest font-mono focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none"
                />
                {pinError && (
                  <p className="text-sm text-red-600 mt-2 text-center">{pinError}</p>
                )}
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white font-bold rounded-xl shadow-lg transition"
              >
                Unlock Dashboard
              </button>

              <p className="text-xs text-center text-slate-500">🔒 Admin access is protected</p>
            </form>
          </div>
        </div>
      </div>
    );
  }


  const tabs: { id: Tab; label: string; Icon: typeof Settings }[] = [
    { id: 'general', label: 'General', Icon: Settings },
    { id: 'payment', label: 'Payment & Giving', Icon: CreditCard },
    { id: 'hero', label: 'Home/Hero', Icon: Home },
    { id: 'founder', label: 'Founder', Icon: Users2 },
    { id: 'books', label: 'Books', Icon: BookOpen },
    { id: 'book-orders', label: 'Book Orders', Icon: ShoppingCart },
    { id: 'members', label: 'Members', Icon: Users2 },
    { id: 'events', label: 'Events', Icon: Calendar },
    { id: 'branches', label: 'Branches', Icon: MapPin },
    { id: 'media', label: 'Media', Icon: Film },
    { id: 'orphanage', label: 'Orphanage', Icon: ImageIcon },
    { id: 'orphanage-donations', label: 'Orphan Donations', Icon: HandHeart },
    { id: 'building', label: 'Building', Icon: Building2 },
    { id: 'bible', label: 'Bible School', Icon: BookOpen },
    { id: 'partners', label: 'Partners', Icon: Inbox },
    { id: 'livestream', label: 'Live Stream', Icon: Radio },
    { id: 'home-gallery', label: 'Home Gallery', Icon: ImageIcon },
    { id: 'crusade-truck', label: 'Crusade Truck', Icon: Truck },
    { id: 'building-auditorium', label: 'Building', Icon: Home },
  ];

  const onSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>, callback: (dataUrl: string) => void) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    // Guard against large files crashing the browser's LocalStorage
    const maxSizeMB = 3; // 3MB limit to be safe with LocalStorage
    const fileSizeMB = file.size / 1024 / 1024;
    
    if (fileSizeMB > maxSizeMB) {
      alert(`This file is ${fileSizeMB.toFixed(2)}MB. It is too large to save directly in the browser (max ${maxSizeMB}MB). Please use a smaller image, or paste a URL link instead (especially for videos).`);
      e.target.value = ''; // reset the input
      return;
    }

    const reader = new FileReader();
    reader.onload = () => callback(reader.result as string);
    reader.readAsDataURL(file);
  };

  const fileInputClass = "hidden";
  const uploadBtn = (onFile: (url: string) => void, label = 'Upload Image') => (
    <label className="inline-flex items-center gap-2 px-3 py-2 bg-slate-100 hover:bg-slate-200 rounded-lg text-xs font-medium cursor-pointer transition">
      <Upload className="h-4 w-4" /> {label}
      <input type="file" accept="image/*,video/*" className={fileInputClass} onChange={e => handleFileUpload(e, onFile)} />
    </label>
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
        <div>
          <div className="inline-flex items-center gap-2 bg-amber-100 text-amber-800 px-3 py-1 rounded-full text-xs font-medium mb-2">
            <Lock className="h-3 w-3" /> Admin Area · 🔒 PIN Protected
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold text-slate-900">Admin Dashboard</h1>
          <p className="text-slate-600 mt-1">Edit everything about your church website</p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={handleLogout}
            className="inline-flex items-center gap-2 px-4 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium rounded-xl transition"
            title="Lock dashboard"
          >
            <Lock className="h-4 w-4" /> Lock
          </button>
          <button
            onClick={onSave}
            className="inline-flex items-center gap-2 px-5 py-3 bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 text-white font-semibold rounded-xl shadow-lg transition"
          >
            {saved ? <><span>✓</span> Saved!</> : <><Save className="h-5 w-5" /> Save Changes</>}
          </button>
        </div>
      </div>

      <div className="mb-6 bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-2xl p-4 flex items-start gap-3">
        <div className="h-9 w-9 rounded-lg bg-blue-500 text-white flex items-center justify-center flex-shrink-0">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <rect x="5" y="2" width="14" height="20" rx="2" ry="2" />
            <line x1="12" y1="18" x2="12.01" y2="18" />
          </svg>
        </div>
        <div className="text-sm text-blue-900">
          <p className="font-semibold">📱 Upload directly from your phone</p>
          <p className="text-blue-700 mt-0.5">
            Tap any image box below to pick photos straight from your phone gallery, camera, or files. All images are saved automatically in your browser. (Max 3MB per file)
          </p>
        </div>
      </div>

      <div className="grid lg:grid-cols-[260px_1fr] gap-6">
        {/* Sidebar */}
        <aside className="bg-white rounded-2xl shadow border border-slate-100 p-2 h-fit lg:sticky lg:top-20">
          {tabs.map(t => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition ${
                tab === t.id ? 'bg-slate-900 text-white' : 'text-slate-700 hover:bg-slate-100'
              }`}
            >
              <t.Icon className="h-4 w-4" />
              {t.label}
            </button>
          ))}
        </aside>

        {/* Content */}
        <main className="bg-white rounded-2xl shadow border border-slate-100 p-6 sm:p-8 min-h-[500px]">
          {tab === 'general' && (
            <div className="space-y-5">
              {/* Admin PIN Settings */}
              <div className="bg-gradient-to-r from-red-50 to-orange-50 border border-red-200 rounded-2xl p-5">
                <h3 className="font-bold text-slate-900 mb-3 flex items-center gap-2">
                  <Lock className="h-5 w-5 text-red-600" /> Admin PIN (Password)
                </h3>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Current PIN</label>
                  <input
                    type="password"
                    value={data.adminPin}
                    onChange={e => updateField('adminPin', e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm tracking-widest font-mono focus:ring-2 focus:ring-red-500 outline-none"
                  />
                  <p className="text-xs text-red-700 mt-2">🔒 This PIN protects your admin dashboard. Change it anytime. Default: <span className="font-mono font-bold">7771</span></p>
                </div>
              </div>

              <h2 className="text-xl font-bold mb-4">Church Information</h2>
              <Field label="Church Name" value={data.name} onChange={v => updateField('name', v)} />
              <Field label="Motto / Tagline" value={data.motto} onChange={v => updateField('motto', v)} />
              <Field label="Pastor Name(s)" value={data.pastorName} onChange={v => updateField('pastorName', v)} />
              <Field label="Pastor Bio" value={data.pastorBio} onChange={v => updateField('pastorBio', v)} textarea />
              <Field label="Contact Address" value={data.contactAddress} onChange={v => updateField('contactAddress', v)} />
              <Field label="Contact Phone" value={data.contactPhone} onChange={v => updateField('contactPhone', v)} />
              <Field label="Contact Email" value={data.contactEmail} onChange={v => updateField('contactEmail', v)} />

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Church Logo</label>
                <p className="text-xs text-slate-500 mb-3">Upload from your phone gallery, or paste an emoji / URL below.</p>

                <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center mb-4 p-4 bg-slate-50 rounded-xl border border-slate-200">
                  <div className="h-24 w-24 rounded-2xl bg-white border border-slate-200 shadow-sm flex items-center justify-center overflow-hidden flex-shrink-0">
                    {isImageUrl(data.logo) ? (
                      <img src={data.logo} alt="Logo" className="h-full w-full object-contain" />
                    ) : (
                      <span className="text-5xl">{data.logo || '⛪'}</span>
                    )}
                  </div>
                  <div className="flex-1 w-full">
                    <label className="inline-flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white font-medium rounded-lg cursor-pointer shadow-md transition">
                      <Upload className="h-4 w-4" />
                      Upload from Gallery
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={e => handleFileUpload(e, v => updateField('logo', v))}
                      />
                    </label>
                    <p className="text-xs text-slate-500 mt-2">Works on phone gallery, camera, and computer files</p>
                  </div>
                </div>

                <div className="space-y-2">
                  <input
                    value={data.logo}
                    onChange={e => updateField('logo', e.target.value)}
                    placeholder="Or paste an emoji (e.g. ⛪) or image URL here"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 outline-none text-sm"
                  />
                  <div className="flex gap-2 flex-wrap">
                    <span className="text-xs text-slate-500 self-center">Quick pick:</span>
                    {['⛪', '✝️', '🕊️', '📖', '🙏'].map(e => (
                      <button
                        key={e}
                        onClick={() => updateField('logo', e)}
                        className={`h-9 w-9 rounded-lg border text-lg transition ${data.logo === e ? 'bg-amber-100 border-amber-500' : 'bg-white border-slate-200 hover:border-amber-400'}`}
                      >
                        {e}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {tab === 'founder' && (
            <div className="space-y-5">
              <h2 className="text-xl font-bold mb-4">Founder Profile</h2>
              <Field label="Name" value={data.founder.name} onChange={v => updateField('founder', { ...data.founder, name: v })} />
              <Field label="Title" value={data.founder.title} onChange={v => updateField('founder', { ...data.founder, title: v })} />
              <Field label="Signature" value={data.founder.signature} onChange={v => updateField('founder', { ...data.founder, signature: v })} />
              <Field label="Inspirational Quote" value={data.founder.quote} onChange={v => updateField('founder', { ...data.founder, quote: v })} textarea />
              <Field label="Biography" value={data.founder.bio} onChange={v => updateField('founder', { ...data.founder, bio: v })} textarea />
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Years in Ministry</label>
                <input type="number" value={data.founder.yearsInMinistry} onChange={e => updateField('founder', { ...data.founder, yearsInMinistry: Number(e.target.value) })} className="px-3 py-2 border border-slate-300 rounded-lg w-32" />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Profile Photo</label>
                <input value={data.founder.image} onChange={e => updateField('founder', { ...data.founder, image: e.target.value })} placeholder="Image URL" className="w-full px-3 py-2 border border-slate-300 rounded-lg mb-2" />
                {uploadBtn(v => updateField('founder', { ...data.founder, image: v }))}
                {data.founder.image && <img src={data.founder.image} className="mt-3 h-40 w-32 object-cover rounded-xl shadow" alt="Founder" />}
              </div>
            </div>
          )}

          {tab === 'books' && (
            <ListEditor
              title="Books for Sale"
              items={data.books}
              setItems={m => updateField('books', m)}
              empty={{ id: '', title: '', author: data.founder.name, cover: '', description: '', price: 19.99, buyLink: '#give' } as Book}
              render={(m, set) => (
                <>
                  <Field label="Title" value={m.title} onChange={v => set({ ...m, title: v } as Book)} />
                  <Field label="Author" value={m.author} onChange={v => set({ ...m, author: v } as Book)} />
                  <Field label="Description" value={m.description} onChange={v => set({ ...m, description: v } as Book)} textarea />
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">Price (USD)</label>
                    <input type="number" step="0.01" value={m.price} onChange={e => set({ ...m, price: Number(e.target.value) } as Book)} className="px-3 py-2 border border-slate-300 rounded-lg w-40" />
                  </div>
                  <Field label="Buy Link" value={m.buyLink} onChange={v => set({ ...m, buyLink: v } as Book)} />
                  <ImageField label="Cover Image" value={m.cover} onChange={v => set({ ...m, cover: v } as Book)} />
                  {m.cover && <img src={m.cover} className="mt-3 h-40 w-32 object-cover rounded-lg shadow ring-4 ring-amber-100" alt={m.title} />}
                </>
              )}
              display={(m) => `${m.title} — $${(m as Book).price}`}
            />
          )}

          {tab === 'book-orders' && (
            <div className="space-y-5">
              <div>
                <h2 className="text-xl font-bold">Book Orders</h2>
                <p className="text-sm text-slate-600">Track all book purchases from the online book store</p>
              </div>

              <div className="bg-white border border-slate-200 rounded-2xl p-5">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <div className="h-9 w-9 rounded-lg bg-amber-100 flex items-center justify-center">
                      <ShoppingCart className="h-5 w-5 text-amber-600" />
                    </div>
                    <div>
                      <h3 className="font-bold">All Book Orders</h3>
                      <p className="text-xs text-slate-500">
                        {data.bookPurchases.length} order(s)
                        {data.bookPurchases.reduce((a, b) => a + (b.totalPrice || 0), 0) > 0 &&
                          ` · Total revenue: $${data.bookPurchases.reduce((a, b) => a + (b.totalPrice || 0), 0).toFixed(2)}`}
                        {data.bookPurchases.reduce((a, b) => a + (b.quantity || 0), 0) > 0 &&
                          ` · ${data.bookPurchases.reduce((a, b) => a + (b.quantity || 0), 0)} book(s)`}
                      </p>
                    </div>
                  </div>
                  {data.bookPurchases.length > 0 && (
                    <button onClick={() => { if (confirm('Clear all book orders?')) updateField('bookPurchases', []); }} className="text-xs text-red-500 hover:bg-red-50 px-2 py-1 rounded">Clear</button>
                  )}
                </div>
                {data.bookPurchases.length === 0 ? (
                  <p className="text-sm text-slate-500 text-center py-6">No orders yet. They'll appear here when customers place orders.</p>
                ) : (
                  <div className="space-y-2 max-h-96 overflow-y-auto">
                    {data.bookPurchases.slice().reverse().map(o => {
                      const items = o.items && o.items.length > 0 ? o.items : [{ bookTitle: o.bookTitle || 'Unknown', quantity: o.quantity || 0 }];
                      return (
                        <div key={o.id} className="p-3 bg-amber-50 rounded-lg">
                          <div className="flex items-start justify-between gap-2">
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2 flex-wrap">
                                <p className="font-semibold text-sm text-slate-900">{o.fullName}</p>
                                <span className="text-xs bg-amber-500 text-white px-2 py-0.5 rounded-full font-bold">${o.totalPrice.toFixed(2)}</span>
                                <span className="text-xs bg-slate-700 text-white px-2 py-0.5 rounded-full">×{items.reduce((a, b) => a + (b.quantity || 0), 0)} items</span>
                                <span className="text-xs bg-white border border-slate-200 px-2 py-0.5 rounded-full capitalize">{o.paymentMethod}</span>
                              </div>
                              <div className="mt-1 space-y-0.5">
                                {items.map((it, i) => (
                                  <p key={i} className="text-sm text-slate-700 italic">
                                    📖 "{it.bookTitle}" × {it.quantity}{'price' in it && it.price ? ` · $${((it as any).price * it.quantity).toFixed(2)}` : ''}
                                  </p>
                                ))}
                              </div>
                              <p className="text-xs text-slate-500 mt-1">
                                {o.email} {o.phone && `· ${o.phone}`} · {new Date(o.submittedAt).toLocaleString()}
                              </p>
                              {o.shippingAddress && <p className="text-xs text-slate-700 mt-1">📦 {o.shippingAddress}</p>}
                              {o.message && <p className="text-xs text-slate-600 mt-1">💬 {o.message}</p>}
                            </div>
                            <button onClick={() => updateField('bookPurchases', data.bookPurchases.filter(x => x.id !== o.id))} className="text-red-500 hover:bg-red-50 p-1.5 rounded flex-shrink-0">
                              <Trash2 className="h-4 w-4" />
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          )}

          {tab === 'payment' && (
            <div className="space-y-6">
              <div>
                <h2 className="text-xl font-bold">Payment & Giving Settings</h2>
                <p className="text-sm text-slate-600">Edit all MoMo, Bank Transfer, PayPal, and giving information in one place. Changes reflect across all pages.</p>
              </div>

              {/* Giving Info */}
              <div className="bg-gradient-to-r from-amber-50 to-orange-50 border border-amber-200 rounded-2xl p-5">
                <h3 className="font-bold text-slate-900 mb-3 flex items-center gap-2">
                  <Heart className="h-5 w-5 text-amber-600" /> General Giving Info
                </h3>
                <Field label="Giving Page Title" value={data.givingTitle} onChange={v => updateField('givingTitle', v)} />
                <div className="mt-3">
                  <Field label="Giving Description" value={data.givingDescription} onChange={v => updateField('givingDescription', v)} textarea />
                </div>
              </div>

              {/* MoMo Details */}
              <div className="bg-gradient-to-r from-emerald-50 to-green-50 border border-emerald-200 rounded-2xl p-5">
                <h3 className="font-bold text-slate-900 mb-3 flex items-center gap-2">
                  📱 Mobile Money (MoMo)
                </h3>
                <div className="grid sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">MoMo Number</label>
                    <input value={data.momoNumber} onChange={e => updateField('momoNumber', e.target.value)} className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-emerald-500 outline-none" placeholder="+233 24 123 4567" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">Network</label>
                    <input value={data.momoNetwork} onChange={e => updateField('momoNetwork', e.target.value)} className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-emerald-500 outline-none" placeholder="MTN MoMo" />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-medium text-slate-700 mb-1">Account Name</label>
                    <input value={data.momoName} onChange={e => updateField('momoName', e.target.value)} className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-emerald-500 outline-none" />
                  </div>
                </div>
                <p className="text-xs text-emerald-700 mt-3">💚 "Send via MoMo" buttons on all pages will use this number. Tapping opens the phone dialer.</p>
              </div>

              {/* Bank Transfer */}
              <div className="bg-gradient-to-r from-indigo-50 to-slate-50 border border-indigo-200 rounded-2xl p-5">
                <h3 className="font-bold text-slate-900 mb-3 flex items-center gap-2">
                  🏦 Bank Transfer
                </h3>
                <div className="grid sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">Bank Name</label>
                    <input value={data.bankName} onChange={e => updateField('bankName', e.target.value)} className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 outline-none" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">Account Name</label>
                    <input value={data.accountName} onChange={e => updateField('accountName', e.target.value)} className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 outline-none" />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-medium text-slate-700 mb-1">Account Number</label>
                    <input value={data.accountNumber} onChange={e => updateField('accountNumber', e.target.value)} className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 outline-none font-mono tracking-wider" />
                  </div>
                </div>
                <p className="text-xs text-indigo-700 mt-3">🏦 Bank details shown on Give, Live Stream, Crusade Truck, Building, and Orphanage pages.</p>
              </div>

              {/* Payment Gateway Link */}
              <div className="bg-gradient-to-r from-blue-50 to-cyan-50 border border-blue-200 rounded-2xl p-5">
                <h3 className="font-bold text-slate-900 mb-3 flex items-center gap-2">
                  💳 Payment Gateway Link (Paystack / Flutterwave / Bank)
                </h3>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Payment URL</label>
                  <input value={data.paymentLink} onChange={e => updateField('paymentLink', e.target.value)} placeholder="https://paystack.com/pay/your-link" className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 outline-none" />
                </div>
                <p className="text-xs text-blue-700 mt-3">💳 The "💳 Pay via Bank App" button on all pages opens this URL. Supports Paystack, Flutterwave, or any online payment link.</p>
              </div>

              {/* PayPal */}
              <div className="bg-gradient-to-r from-sky-50 to-blue-50 border border-sky-200 rounded-2xl p-5">
                <h3 className="font-bold text-slate-900 mb-3 flex items-center gap-2">
                  💙 PayPal
                </h3>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">PayPal Link</label>
                  <input value={data.paypalLink} onChange={e => updateField('paypalLink', e.target.value)} placeholder="https://paypal.me/your-church" className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-sky-500 outline-none" />
                </div>
                <p className="text-xs text-sky-700 mt-3">💙 "PayPal Giving" buttons on all pages open this link. Great for international donors.</p>
              </div>

              {/* Where these appear */}
              <div className="bg-slate-50 border border-slate-200 rounded-2xl p-5">
                <h3 className="font-bold text-slate-900 mb-3">🌐 Where These Settings Appear</h3>
                <div className="grid sm:grid-cols-2 gap-2 text-sm">
                  {[
                    { page: 'Give Page', uses: 'MoMo, Bank, PayPal' },
                    { page: 'Live Stream', uses: 'MoMo, Bank, Payment Link' },
                    { page: 'Crusade Truck', uses: 'MoMo, Bank, PayPal' },
                    { page: 'Building Project', uses: 'MoMo, Bank, PayPal' },
                    { page: 'Orphanage', uses: 'MoMo, Bank' },
                  ].map(p => (
                    <div key={p.page} className="flex justify-between bg-white px-3 py-2 rounded-lg border border-slate-100">
                      <span className="font-medium text-slate-900">{p.page}</span>
                      <span className="text-xs text-slate-500">{p.uses}</span>
                    </div>
                  ))}
                </div>
                <p className="text-xs text-slate-500 mt-3">✨ Edit any value here and it updates everywhere automatically!</p>
              </div>
            </div>
          )}

          {tab === 'hero' && (
            <div className="space-y-5">
              <h2 className="text-xl font-bold mb-4">Home Page / Hero Video</h2>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Hero Video (plays behind the home page hero)</label>
                <label className="group relative block w-full h-48 rounded-xl border-2 border-dashed border-slate-300 bg-gradient-to-br from-slate-50 to-slate-100 hover:border-amber-500 hover:from-amber-50 hover:to-amber-50 transition cursor-pointer overflow-hidden">
                  {data.heroVideoUrl ? (
                    <>
                      <video src={data.heroVideoUrl} controls muted className="absolute inset-0 w-full h-full object-cover" />
                      <div className="absolute top-2 right-2 bg-black/70 text-white px-2 py-1 rounded text-xs">Preview</div>
                      <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition flex flex-col items-center justify-center text-white">
                        <Upload className="h-6 w-6 mb-1" />
                        <span className="text-sm font-medium">Tap to replace video</span>
                      </div>
                    </>
                  ) : (
                    <div className="absolute inset-0 flex flex-col items-center justify-center text-slate-500">
                      <Upload className="h-8 w-8 mb-1 text-amber-500" />
                      <span className="text-base font-semibold text-slate-700">Tap to upload video from phone</span>
                      <span className="text-xs text-slate-500 mt-1">MP4, MOV, or WEBM · or paste URL below</span>
                    </div>
                  )}
                  <input
                    type="file"
                    accept="video/*"
                    className="hidden"
                    onChange={e => handleFileUpload(e, v => updateField('heroVideoUrl', v))}
                  />
                </label>
                <input
                  value={data.heroVideoUrl}
                  onChange={e => updateField('heroVideoUrl', e.target.value)}
                  placeholder="Or paste a video URL here"
                  className="w-full mt-2 px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-amber-500 outline-none"
                />
              </div>

              <h3 className="text-lg font-bold mt-6 pt-6 border-t border-slate-200">Giving Information</h3>
              <Field label="Giving Title" value={data.givingTitle} onChange={v => updateField('givingTitle', v)} />
              <Field label="Giving Description" value={data.givingDescription} onChange={v => updateField('givingDescription', v)} textarea />
              <Field label="Bank Name" value={data.bankName} onChange={v => updateField('bankName', v)} />
              <Field label="Account Name" value={data.accountName} onChange={v => updateField('accountName', v)} />
              <Field label="Account Number" value={data.accountNumber} onChange={v => updateField('accountNumber', v)} />
              <Field label="PayPal Link" value={data.paypalLink} onChange={v => updateField('paypalLink', v)} />
            </div>
          )}

          {tab === 'members' && (
            <ListEditor
              title="Church Members"
              items={data.members}
              setItems={m => updateField('members', m)}
              empty={{ id: '', name: '', role: '', phone: '', email: '', joinedDate: new Date().toISOString().slice(0, 10), photo: 'https://i.pravatar.cc/150' }}
              render={(m, set) => (
                <>
                  <Field label="Name" value={m.name} onChange={v => set({ ...m, name: v })} />
                  <Field label="Role/Ministry" value={m.role} onChange={v => set({ ...m, role: v })} />
                  <Field label="Phone" value={m.phone} onChange={v => set({ ...m, phone: v })} />
                  <Field label="Email" value={m.email} onChange={v => set({ ...m, email: v })} />
                  <Field label="Joined Date" value={m.joinedDate} onChange={v => set({ ...m, joinedDate: v })} />
                  <ImageField label="Member Photo" value={m.photo} onChange={v => set({ ...m, photo: v })} />
                  {m.photo && <img src={m.photo} className="h-20 w-20 rounded-full object-cover mt-2 ring-4 ring-amber-100" alt="" />}
                </>
              )}
              display={(m) => `${m.name} — ${m.role}`}
            />
          )}

          {tab === 'events' && (
            <ListEditor
              title="Events & Services"
              items={data.events}
              setItems={m => updateField('events', m)}
              empty={{ id: '', title: '', date: '', time: '', description: '', image: '', type: 'service' as const }}
              render={(m, set) => (
                <>
                  <Field label="Title" value={m.title} onChange={v => set({ ...m, title: v })} />
                  <div className="grid grid-cols-2 gap-3">
                    <Field label="Date" value={m.date} onChange={v => set({ ...m, date: v })} />
                    <Field label="Time" value={m.time} onChange={v => set({ ...m, time: v })} />
                  </div>
                  <Field label="Description" value={m.description} onChange={v => set({ ...m, description: v })} textarea />
                  <Field label="Image URL" value={m.image} onChange={v => set({ ...m, image: v })} />
                  <div>{uploadBtn(v => set({ ...m, image: v }))}</div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">Type</label>
                    <select value={m.type} onChange={e => set({ ...m, type: e.target.value as 'service' | 'event' })} className="px-3 py-2 border border-slate-300 rounded-lg">
                      <option value="service">Service</option>
                      <option value="event">Event</option>
                    </select>
                  </div>
                </>
              )}
              display={(m) => `${m.title} — ${m.date}`}
            />
          )}

          {tab === 'branches' && (
            <ListEditor
              title="Church Branches"
              items={data.branches}
              setItems={m => updateField('branches', m)}
              empty={{ id: '', name: '', address: '', pastor: '', phone: '', image: '' }}
              render={(m, set) => (
                <>
                  <Field label="Branch Name" value={m.name} onChange={v => set({ ...m, name: v })} />
                  <Field label="Address" value={m.address} onChange={v => set({ ...m, address: v })} />
                  <Field label="Pastor" value={m.pastor} onChange={v => set({ ...m, pastor: v })} />
                  <Field label="Phone" value={m.phone} onChange={v => set({ ...m, phone: v })} />
                  <ImageField label="Branch Image" value={m.image} onChange={v => set({ ...m, image: v })} />
                </>
              )}
              display={(m) => m.name}
            />
          )}

          {tab === 'media' && (
            <div className="space-y-8">
              <ListEditor
                title="Media (YouTube, TikTok, Instagram)"
                items={data.media}
                setItems={m => updateField('media', m)}
                empty={{ id: '', title: '', url: '', platform: 'youtube' as const, thumbnail: '' }}
                render={(m, set) => (
                  <>
                    <Field label="Title" value={m.title} onChange={v => set({ ...m, title: v })} />
                    <Field label="URL (embed link)" value={m.url} onChange={v => set({ ...m, url: v })} />
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-2">Platform</label>
                      <select value={m.platform} onChange={e => set({ ...m, platform: e.target.value as 'youtube' | 'tiktok' | 'instagram' })} className="px-3 py-2 border border-slate-300 rounded-lg">
                        <option value="youtube">YouTube</option>
                        <option value="tiktok">TikTok</option>
                        <option value="instagram">Instagram</option>
                      </select>
                    </div>
                    <ImageField label="Thumbnail" value={m.thumbnail} onChange={v => set({ ...m, thumbnail: v })} />
                  </>
                )}
                display={(m) => `${m.title} (${m.platform})`}
              />

              {/* Testimonies */}
              <div className="pt-8 border-t-2 border-slate-200">
                <div className="mb-4">
                  <div className="inline-flex items-center gap-2 bg-purple-100 text-purple-700 px-3 py-1 rounded-full text-xs font-medium mb-2">
                    🎬 Testimonies
                  </div>
                  <h2 className="text-xl font-bold">Church Testimonies</h2>
                  <p className="text-sm text-slate-600">Add video testimonies — paste a URL or upload from your phone gallery</p>
                </div>
                <ListEditor
                  title=""
                  items={data.testimonies}
                  setItems={m => updateField('testimonies', m)}
                  empty={{ id: '', title: '', author: '', videoUrl: '', description: '', submittedAt: Date.now() }}
                  render={(m, set) => (
                    <>
                      <Field label="Testimony Title" value={m.title} onChange={v => set({ ...m, title: v })} />
                      <Field label="Author / Testifier" value={m.author} onChange={v => set({ ...m, author: v })} />
                      <Field label="Description / Summary" value={m.description} onChange={v => set({ ...m, description: v })} textarea />
                      <div>
                        <label className="block text-sm font-medium text-slate-700 mb-2">Video</label>
                        <label className="group relative block w-full h-44 rounded-xl border-2 border-dashed border-slate-300 bg-gradient-to-br from-purple-50 to-slate-50 hover:border-purple-500 transition cursor-pointer overflow-hidden">
                          {m.videoUrl ? (
                            <>
                              <video src={m.videoUrl} className="absolute inset-0 w-full h-full object-cover" />
                              <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition flex flex-col items-center justify-center text-white">
                                <Upload className="h-6 w-6 mb-1" />
                                <span className="text-sm font-medium">Tap to replace video</span>
                              </div>
                            </>
                          ) : (
                            <div className="absolute inset-0 flex flex-col items-center justify-center text-slate-500">
                              <Upload className="h-8 w-8 mb-1 text-purple-500" />
                              <span className="text-base font-semibold text-slate-700">Tap to upload from phone gallery</span>
                              <span className="text-xs text-slate-500 mt-1">or paste a video URL below</span>
                            </div>
                          )}
                          <input
                            type="file"
                            accept="video/*"
                            className="hidden"
                            onChange={e => {
                              const file = e.target.files?.[0];
                              if (!file) return;
                              const reader = new FileReader();
                              reader.onload = () => set({ ...m, videoUrl: reader.result as string });
                              reader.readAsDataURL(file);
                            }}
                          />
                        </label>
                        <input
                          value={m.videoUrl}
                          onChange={e => set({ ...m, videoUrl: e.target.value })}
                          placeholder="Or paste video URL (mp4, YouTube, etc.)"
                          className="w-full mt-2 px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-purple-500 outline-none"
                        />
                      </div>
                    </>
                  )}
                  display={(m) => `${m.title} — ${m.author || 'Unknown'}`}
                />
              </div>
            </div>
          )}

          {tab === 'orphanage' && (
            <div className="space-y-5">
              <h2 className="text-xl font-bold mb-4">Orphanage Gallery</h2>
              <Field label="Description" value={data.orphanageDescription} onChange={v => updateField('orphanageDescription', v)} textarea />
              <GalleryEditor
                items={data.orphanageImages}
                setItems={m => updateField('orphanageImages', m)}
                empty={{ id: '', src: '', caption: '' }}
              />
            </div>
          )}

          {tab === 'building' && (
            <div className="space-y-5">
              <h2 className="text-xl font-bold mb-4">Building Project</h2>
              <Field label="Project Description" value={data.buildingProjectDescription} onChange={v => updateField('buildingProjectDescription', v)} textarea />
              <GalleryEditor
                items={data.buildingImages}
                setItems={m => updateField('buildingImages', m)}
                empty={{ id: '', src: '', caption: '' }}
              />
            </div>
          )}

          {tab === 'bible' && (
            <div className="space-y-5">
              <h2 className="text-xl font-bold mb-4">Bible School</h2>
              <Field label="Description" value={data.bibleSchoolDescription} onChange={v => updateField('bibleSchoolDescription', v)} textarea />
              <GalleryEditor
                items={data.bibleImages}
                setItems={m => updateField('bibleImages', m)}
                empty={{ id: '', src: '', caption: '' }}
              />
            </div>
          )}

          {tab === 'orphanage-donations' && (
            <div className="space-y-5">
              <div>
                <h2 className="text-xl font-bold">Orphanage Donations</h2>
                <p className="text-sm text-slate-600">Track all donations for {data.orphanageName} (funds, clothes, food, school materials, etc.)</p>
              </div>

              {/* Orphanage Settings */}
              <div className="bg-gradient-to-r from-pink-50 to-rose-50 border border-pink-200 rounded-2xl p-5">
                <h3 className="font-bold text-slate-900 mb-3 flex items-center gap-2">
                  <HandHeart className="h-5 w-5 text-pink-600" /> Orphanage Settings
                </h3>
                <div className="space-y-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">Orphanage Name</label>
                    <input
                      value={data.orphanageName}
                      onChange={e => updateField('orphanageName', e.target.value)}
                      placeholder="e.g., Grace Haven Orphanage"
                      className="w-full px-3 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-pink-500 outline-none"
                    />
                    <p className="text-xs text-slate-500 mt-1">This name appears on the Orphanage page, Home page, and donation confirmations.</p>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">Orphanage Description</label>
                    <textarea
                      value={data.orphanageDescription}
                      onChange={e => updateField('orphanageDescription', e.target.value)}
                      rows={3}
                      className="w-full px-3 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-pink-500 outline-none"
                    />
                  </div>
                </div>
              </div>

              <div className="bg-white border border-slate-200 rounded-2xl p-5">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <div className="h-9 w-9 rounded-lg bg-pink-100 flex items-center justify-center">
                      <HandHeart className="h-5 w-5 text-pink-600" />
                    </div>
                    <div>
                      <h3 className="font-bold">All Orphanage Donations</h3>
                      <p className="text-xs text-slate-500">
                        {data.orphanageDonations.length} donation(s)
                        {data.orphanageDonations.filter(d => d.donationType === 'funds').reduce((a, b) => a + (b.amount || 0), 0) > 0 &&
                          ` · Cash total: $${data.orphanageDonations.filter(d => d.donationType === 'funds').reduce((a, b) => a + (b.amount || 0), 0).toFixed(2)}`}
                      </p>
                    </div>
                  </div>
                  {data.orphanageDonations.length > 0 && (
                    <button onClick={() => { if (confirm('Clear all orphanage donations?')) updateField('orphanageDonations', []); }} className="text-xs text-red-500 hover:bg-red-50 px-2 py-1 rounded">Clear</button>
                  )}
                </div>
                {data.orphanageDonations.length === 0 ? (
                  <p className="text-sm text-slate-500 text-center py-6">No donations yet. They'll appear here when supporters submit.</p>
                ) : (
                  <div className="space-y-2 max-h-96 overflow-y-auto">
                    {data.orphanageDonations.slice().reverse().map(d => {
                      const typeColors: Record<string, string> = {
                        funds: 'bg-emerald-50 text-emerald-700 border-emerald-200',
                        clothes: 'bg-pink-50 text-pink-700 border-pink-200',
                        school: 'bg-blue-50 text-blue-700 border-blue-200',
                        food: 'bg-amber-50 text-amber-700 border-amber-200',
                        toiletries: 'bg-cyan-50 text-cyan-700 border-cyan-200',
                        other: 'bg-purple-50 text-purple-700 border-purple-200',
                      };
                      return (
                        <div key={d.id} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <p className="font-semibold text-sm text-slate-900">{d.fullName}</p>
                              <span className={`text-xs px-2 py-0.5 rounded-full border capitalize ${typeColors[d.donationType] || 'bg-slate-50 text-slate-700'}`}>
                                {d.donationType}
                              </span>
                              {d.donationType === 'funds' && d.amount > 0 && (
                                <span className="text-xs font-bold text-emerald-700">${d.amount.toFixed(2)}</span>
                              )}
                            </div>
                            <p className="text-xs text-slate-500 mt-0.5">
                              {d.email && `${d.email} · `}{d.phone && `${d.phone} · `}{new Date(d.submittedAt).toLocaleString()}
                            </p>
                            {d.itemDescription && <p className="text-xs text-slate-700 mt-1 italic">📦 {d.itemDescription}</p>}
                            {d.message && <p className="text-xs text-slate-600 mt-1">💬 {d.message}</p>}
                          </div>
                          <button onClick={() => updateField('orphanageDonations', data.orphanageDonations.filter(x => x.id !== d.id))} className="text-red-500 hover:bg-red-50 p-1.5 rounded flex-shrink-0">
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          )}

          {tab === 'building-auditorium' && (
            <div className="space-y-5">
              <div>
                <h2 className="text-xl font-bold">Building Auditorium Campaign</h2>
                <p className="text-sm text-slate-600">Manage the auditorium image, goal, and track donations</p>
              </div>

              {/* Building Image Upload */}
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Auditorium Image</label>
                <label className="group relative block w-full h-56 rounded-xl border-2 border-dashed border-slate-300 bg-gradient-to-br from-slate-50 to-slate-100 hover:border-amber-500 hover:from-amber-50 hover:to-amber-50 transition cursor-pointer overflow-hidden">
                  {data.buildingAuditoriumImage ? (
                    <>
                      <img src={data.buildingAuditoriumImage} alt="Building" className="absolute inset-0 w-full h-full object-cover" />
                      <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition flex flex-col items-center justify-center text-white">
                        <Upload className="h-6 w-6 mb-1" />
                        <span className="text-sm font-medium">Tap to replace from phone gallery</span>
                      </div>
                    </>
                  ) : (
                    <div className="absolute inset-0 flex flex-col items-center justify-center text-slate-500">
                      <Upload className="h-8 